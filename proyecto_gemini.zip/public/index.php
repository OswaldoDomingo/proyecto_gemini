<?php
// Punto de entrada
echo "Hola desde Proyecto Gemini";
