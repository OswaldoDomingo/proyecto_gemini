<?php
// Configuración básica de conexión (se ajustará después)
return [
    'host' => 'localhost',
    'port' => 3306,
    'dbname' => 'proyecto_gemini',
    'user' => 'root',
    'password' => ''
];
